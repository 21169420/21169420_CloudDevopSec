var firebaseConfig = {
  apiKey: "AIzaSyBj24Uqf617p8mAdv6HCoxvHI7LM2nR6qk",
  authDomain: "python-web-343814.firebaseapp.com",
  projectId: "python-web-343814",
  storageBucket: "python-web-343814.appspot.com",
  messagingSenderId: "884384911696",
  appId: "1:884384911696:web:ffa20350ff5172ad0a9c55",
  measurementId: "G-F0VHFM9LMX",
  databaseURL:
    "https://python-web-343814-default-rtdb.europe-west1.firebasedatabase.app/",
};
firebase.initializeApp(firebaseConfig);
